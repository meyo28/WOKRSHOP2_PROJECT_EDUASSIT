<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] != 'student' && $_SESSION['user_type'] != 'lecturer')) {
    header("Location: index.php?error=login_required");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grammar Checker - SILS</title>
    <style>
        /* ===== ORIGINAL STYLES (preserved) ===== */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #f0f2f5; }
        .header { background: #003366; color: white; padding: 20px; text-align: center; }
        .container { max-width: 1000px; margin: 30px auto; background: white; border-radius: 15px; padding: 25px; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #003366; text-decoration: none; }
        .info { font-size: 13px; color: #666; margin-bottom: 15px; background: #e8f0fe; padding: 10px; border-radius: 8px; }
        
        /* ===== ENHANCED STYLES ===== */
        .editor-wrapper {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 2px rgba(0,0,0,0.02);
        }
        .editor-wrapper:focus-within {
            border-color: #2c6e9e;
            box-shadow: 0 0 0 3px rgba(44,110,158,0.1);
        }
        textarea {
            width: 100%;
            padding: 18px;
            font-size: 15px;
            line-height: 1.6;
            border: none;
            border-radius: 12px 12px 0 0;
            font-family: 'Poppins', monospace;
            resize: vertical;
            background: #ffffff;
            color: #1a2c3e;
        }
        textarea:focus {
            outline: none;
        }
        .status-bar {
            display: flex;
            justify-content: flex-end;
            gap: 20px;
            padding: 8px 16px;
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            border-radius: 0 0 12px 12px;
            font-size: 12px;
            color: #475569;
            font-weight: 500;
        }
        .char-warning { color: #e67e22; font-weight: 600; }
        .char-exceed { color: #c00; font-weight: 700; }
        .duplicate-warning {
            background: #fff3e0;
            border-left: 4px solid #e67e22;
            padding: 10px 16px;
            margin-top: 10px;
            border-radius: 8px;
            font-size: 13px;
            color: #a55117;
        }
        .suggestions {
            background: #fefcf5;
            border: 1px solid #ede9d0;
            border-radius: 14px;
            margin-top: 25px;
            max-height: 450px;
            overflow-y: auto;
        }
        .suggestions-header {
            padding: 14px 20px;
            background: #fef9e6;
            border-bottom: 1px solid #ede9d0;
            font-weight: 600;
            color: #8b5e2e;
            border-radius: 14px 14px 0 0;
            font-size: 14px;
        }
        .error-item {
            border-bottom: 1px solid #ede9d0;
            padding: 16px 20px;
            transition: background 0.1s;
        }
        .error-item:last-child { border-bottom: none; }
        .error-item:hover { background: #fffaf0; }
        .error-msg { font-weight: bold; color: #c00; margin-bottom: 6px; font-size: 14px; }
        .error-context {
            background: #fff;
            padding: 8px 12px;
            border-radius: 10px;
            font-size: 13px;
            color: #1e293b;
            margin: 8px 0;
            border: 1px solid #f0e5cf;
        }
        .error-context mark {
            background-color: #fde047;
            color: #1e1b4b;
            padding: 2px 4px;
            border-radius: 6px;
        }
        .suggestion-simple {
            color: #2b6e3c;
            font-size: 13px;
            margin-top: 6px;
        }
        .loading { color: #64748b; font-style: italic; padding: 20px; text-align: center; }
        .no-errors { color: #2b6e3c; padding: 20px; text-align: center; font-weight: 500; }
    </style>
</head>
<body>
<div class="header"><h1>📝 Grammar Checker</h1></div>
<div class="container">
    <a href="student_dashboard_2.php" class="back-link">← Back to Dashboard</a>
    <div class="info">
        ✍️ Paste or type your essay below. Grammar and style suggestions appear automatically.<br>
        📏 Character limit: <strong>20,000 characters</strong> (LanguageTool API limit). Exceeding this will disable checking.
    </div>

    <div class="editor-wrapper">
        <textarea id="essayText" rows="12" placeholder="Paste your essay here..."></textarea>
        <div class="status-bar">
            <span>📝 Words: <span id="wordCount">0</span></span>
            <span>🔤 Characters: <span id="charCount">0</span> <span id="charLimitMsg"></span></span>
        </div>
    </div>

    <div id="duplicateWarning" class="duplicate-warning" style="display: none;"></div>

    <div id="suggestions" class="suggestions">
        <div class="suggestions-header">🔧 Grammar & Style Suggestions</div>
        <div class="loading">💡 Suggestions will appear as you type.</div>
    </div>
</div>

<script>
    let debounceTimer;
    const textarea = document.getElementById('essayText');
    const suggestionsDiv = document.getElementById('suggestions');
    const wordCountSpan = document.getElementById('wordCount');
    const charCountSpan = document.getElementById('charCount');
    const charLimitMsgSpan = document.getElementById('charLimitMsg');
    const duplicateWarningDiv = document.getElementById('duplicateWarning');
    const CHAR_LIMIT = 20000;

    function updateStats() {
        let text = textarea.value;
        let words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
        let chars = text.length;
        wordCountSpan.innerText = words;
        charCountSpan.innerText = chars;
        if (chars > CHAR_LIMIT) {
            charLimitMsgSpan.innerHTML = '<span class="char-exceed"> ⚠️ Exceeds limit!</span>';
        } else if (chars > CHAR_LIMIT * 0.9) {
            charLimitMsgSpan.innerHTML = '<span class="char-warning"> ⚠️ Approaching limit</span>';
        } else {
            charLimitMsgSpan.innerHTML = '';
        }
        return chars;
    }

    // Check for duplicate paragraphs using plain object (no Map)
    function checkDuplicateParagraphs(text) {
        let paragraphs = text.split(/\n\s*\n/);
        paragraphs = paragraphs.filter(function(p) { return p.trim().length > 20; });
        let seen = {};
        let duplicates = [];
        for (let i = 0; i < paragraphs.length; i++) {
            let normalized = paragraphs[i].trim().toLowerCase();
            if (seen.hasOwnProperty(normalized)) {
                duplicates.push({
                    first: seen[normalized] + 1,
                    second: i + 1,
                    preview: paragraphs[i].substring(0, 80) + (paragraphs[i].length > 80 ? '…' : '')
                });
            } else {
                seen[normalized] = i;
            }
        }
        if (duplicates.length > 0) {
            let msg = '⚠️ Duplicate paragraph detected (paragraph ' + duplicates[0].first + ' and ' + duplicates[0].second + '): “' + duplicates[0].preview + '”';
            duplicateWarningDiv.style.display = 'block';
            duplicateWarningDiv.innerHTML = msg;
        } else {
            duplicateWarningDiv.style.display = 'none';
        }
    }

    // Custom check: missing punctuation at end of each paragraph
    function checkMissingEndPunctuation(text) {
        let paragraphs = text.split(/\n\s*\n/);
        if (text.trim() !== '' && paragraphs.length === 0) paragraphs = [text];
        let missing = [];
        for (let i = 0; i < paragraphs.length; i++) {
            let para = paragraphs[i].trim();
            if (para.length === 0) continue;
            let lastChar = para.charAt(para.length - 1);
            if (['.', '!', '?'].indexOf(lastChar) === -1) {
                let lastNonQuote = para.replace(/["'\]\)]$/, '').trim();
                if (lastNonQuote.length > 0) {
                    let lastChar2 = lastNonQuote.charAt(lastNonQuote.length - 1);
                    if (['.', '!', '?'].indexOf(lastChar2) === -1) {
                        missing.push({
                            paragraphIndex: i + 1,
                            preview: para.substring(0, 100) + (para.length > 100 ? '…' : '')
                        });
                    }
                }
            }
        }
        return missing;
    }

    async function checkGrammar(text) {
        let chars = text.length;
        if (text.trim().length < 5) {
            suggestionsDiv.innerHTML = '<div class="suggestions-header">🔧 Grammar & Style Suggestions</div><div class="loading">💡 Suggestions will appear automatically.</div>';
            return;
        }
        if (chars > CHAR_LIMIT) {
            suggestionsDiv.innerHTML = '<div class="suggestions-header">🔧 Grammar & Style Suggestions</div><div class="error-item"><div class="error-msg">⚠️ Character limit exceeded (' + CHAR_LIMIT + ' max). Please shorten your essay.</div></div>';
            return;
        }

        suggestionsDiv.innerHTML = '<div class="suggestions-header">🔧 Grammar & Style Suggestions</div><div class="loading">🔍 Checking grammar...</div>';
        try {
            const response = await fetch('api/grammar_check_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'text=' + encodeURIComponent(text)
            });
            const data = await response.json();
            let apiMatches = data.matches || [];
            if (data.error) {
                apiMatches = [];
            }
            const missingPunctuation = checkMissingEndPunctuation(text);
            let combinedMatches = apiMatches.slice();
            for (let i = 0; i < missingPunctuation.length; i++) {
                combinedMatches.push({
                    message: 'Missing ending punctuation (., !, or ?) at the end of a paragraph.',
                    replacements: [{ value: '.' }],
                    context: { text: missingPunctuation[i].preview },
                    offset: 0,
                    length: 0
                });
            }
            displaySuggestions(combinedMatches);
        } catch (err) {
            suggestionsDiv.innerHTML = '<div class="suggestions-header">🔧 Grammar & Style Suggestions</div><div class="error-item"><div class="error-msg">❌ Network error: ' + escapeHtml(err.message) + '</div></div>';
        }
    }

    function cleanReplacements(replacements) {
        if (!replacements || !Array.isArray(replacements)) return 'No suggestion';
        let cleaned = [];
        for (let i = 0; i < replacements.length; i++) {
            let v = replacements[i].value;
            if (v && v.trim().length > 1 && v.length <= 20 && !(/^[^a-z]/i.test(v))) {
                if (cleaned.indexOf(v) === -1) cleaned.push(v);
            }
        }
        if (cleaned.length === 0) return 'No suggestion';
        return cleaned.slice(0, 3).join(', ');
    }

    function highlightError(context, errorWord) {
        if (!context || !errorWord) return context;
        let lowerContext = context.toLowerCase();
        let lowerWord = errorWord.toLowerCase();
        let idx = lowerContext.indexOf(lowerWord);
        if (idx === -1) return context;
        let before = context.substring(0, idx);
        let word = context.substring(idx, idx + errorWord.length);
        let after = context.substring(idx + errorWord.length);
        return before + '<mark>' + word + '</mark>' + after;
    }

    function displaySuggestions(matches) {
        if (!matches || matches.length === 0) {
            suggestionsDiv.innerHTML = '<div class="suggestions-header">🔧 Grammar & Style Suggestions</div><div class="no-errors">✅ No errors found. Your essay looks good!</div>';
            return;
        }
        let html = '<div class="suggestions-header">🔧 Grammar & Style Suggestions (' + matches.length + ')</div>';
        for (let i = 0; i < matches.length; i++) {
            let m = matches[i];
            let replacements = cleanReplacements(m.replacements);
            let errorWord = '';
            if (m.offset !== undefined && m.length !== undefined && m.context && m.context.text) {
                errorWord = m.context.text.substr(m.offset, m.length);
            } else if (m.context && m.context.text) {
                errorWord = m.context.text.split(/\s+/)[0] || '';
            }
            let highlightedContext = highlightError(m.context.text, errorWord);
            let shortMsg = (m.message || '').replace(/^Possible /i, '').replace(/\.$/, '');
            html += '<div class="error-item">' +
                        '<div class="error-msg">⚠️ ' + escapeHtml(shortMsg) + '</div>' +
                        '<div class="error-context">📌 “' + highlightedContext + '”</div>' +
                        '<div class="suggestion-simple">💡 Try: ' + escapeHtml(replacements) + '</div>' +
                    '</div>';
        }
        suggestionsDiv.innerHTML = html;
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    textarea.addEventListener('input', function() {
        let chars = updateStats();
        let text = this.value;
        checkDuplicateParagraphs(text);
        clearTimeout(debounceTimer);
        if (chars <= CHAR_LIMIT) {
            debounceTimer = setTimeout(function() {
                checkGrammar(text);
            }, 800);
        } else {
            suggestionsDiv.innerHTML = '<div class="suggestions-header">🔧 Grammar & Style Suggestions</div><div class="error-item"><div class="error-msg">⚠️ Character limit exceeded (' + CHAR_LIMIT + ' max). Please shorten your essay.</div></div>';
        }
    });

    updateStats();
    checkDuplicateParagraphs('');
</script>
</body>
</html>